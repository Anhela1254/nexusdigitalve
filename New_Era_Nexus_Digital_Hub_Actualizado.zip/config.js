/* Enlaces comerciales oficiales: New Era – Nexus Digital Hub.
   No mezclar con las redes de ClipNova.
   Cambiar los valores solo si el negocio actualiza sus contactos. */
window.NEW_ERA_CONFIG = {
  whatsapp: "584123570826",
  instagram: "https://www.instagram.com/nexus_digitalve/",
  facebook: "",
  email: ""
};
